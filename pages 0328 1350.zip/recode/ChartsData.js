export const ChartsData = [
  {
    "id": "마피아1",
    "label": "마피아1",
    "value": 558,
    "color": "hsl(106, 70%, 50%)"
  },
  {
    "id": "마피아2", 
    "label": "마피아2",
    "value": 439,
    "color": "hsl(344, 70%, 50%)"
  },
  {
    "id": "마피아3",
    "label": "마피아3",
    "value": 477,
    "color": "hsl(149, 70%, 50%)"
  },
  {
    "id": "마피아4",
    "label": "마피아4",
    "value": 235,
    "color": "hsl(270, 70%, 50%)"
  }
];