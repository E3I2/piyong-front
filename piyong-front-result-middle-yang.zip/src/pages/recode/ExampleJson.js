export const ExampleJson = [
    {
        "id": "1",
        "created_at": "2023-03-10 12:39:53",
        "road1": "0",
        "road1_mafia" : "0",
        "road2": "0",
        "road2_mafia" : "0",
        "road3": "0",
        "road3_mafia" : "0",
        "road4": "0",
        "road4_mafia" : "0"
    },
    {
        "id": "2",
        "created_at": "2023-03-10 14:25:51",
        "road1": "138",
        "road1_mafia" : "mafia_2",
        "road2": "15",
        "road2_mafia" : "0",
        "road3": "98",
        "road3_mafia" : "mafia_1",
        "road4": "100",
        "road4_mafia" : "0"
    },
    {
        "id": "3",
        "created_at": "2023-03-10 15:07:32",
        "road1": "81",
        "road1_mafia" : "mafia_1",
        "road2": "34",
        "road2_mafia" : "mafia_3",
        "road3": "181",
        "road3_mafia" : "mafia_4",
        "road4": "81",
        "road4_mafia" : "mafia_3"
    }
  ];


//   //

//   useEffect(() => {
//     console.log(datachart)
//   const ChartsData = datachart.map(item => ({
//     id: item.name,
//     label: item.user_name,
//     value: item.id,
//     color: item.id
//   }));
//   setChartData(ChartsData);
// }, [datachart]);

//   {
//     "id": "3",
//     "created_at": "2023-03-10 15:07:32",
//     "road1": "81",
//     "road1_mafia" : "mafia_2",
//     "road2": "34",
//     "road2_mafia" : "mafia_3",
//     "road3": "181",
//     "road3_mafia" : "mafia_4",
//     "road4": "81",
//     "road4_mafia" : "maifa_1"
// }


// {
//     "id": "road1",
//     "label" : "mafia_2"
//     "value" : 81,
//     "color" : 81
// },
// {
//     "id": "road2",
//     "label" : "mafia_3"
//     "value" : 34,
//     "color" : 34
// },
// {
//     "id": "road3",
//     "label" : "mafia_4"
//     "value" : 181,
//     "color" : 181
// },
// {
//     "id": "road4",
//     "label" : "mafia_1"
//     "value" : 81,
//     "color" : 81
// },

// {
//     "id": "road1",
//     "mafia" : "mafia_2"
// },
// {
//     "id": "road2",
//     "mafia" : "mafia_3"
// },
// {
//     "id": "road3",
//     "mafia" : "mafia_4"
// },
// {
//     "id": "road4",
//     "mafia" : "mafia_1"
// }